class Medidor:
    def __init__(self, marca, modelo, anodocarro, velocidade=0):
        self.marca = marca
        self.modelo = modelo 
        self.anodocarro = anodocarro
        self.velocidade = velocidade
    
    def acelerar (self):
        self.velocidade += 10
        print(f"Acelerar! Velocidade Atual: {self.velocidade} km/h")

    def freiar (self):
        self.velocidade -= 10
        if self.velocidade < 0:
            self.velocidade = 0
        print(f"Freiar! Velocidade Atual: {self.velocidade} km/h")

    def detalhes (self):
        print(f"Marca do Carro: {self.marca} - Modelo: {self.modelo} - Ano do Carro: {self.anodocarro}")