import medidor
carro = medidor.Medidor("Toyota", "Corolla", "2022")
carro.acelerar()
carro.acelerar()
carro.freiar()
carro.detalhes()

