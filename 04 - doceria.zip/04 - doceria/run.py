import sistema

doce = sistema.Sistema(" Brigadeiro", " Chocolate", 3.50, 50)
doce.detalhes ()
doce.pedido (20)
doce.producao (30)
doce.pedido (200)
doce.producao (300)
doce.pedido (200)
