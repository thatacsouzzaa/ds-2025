class Sistema:
    def __init__(self, nome, sabor, preco, estoque):
        self.nome = nome
        self.sabor = sabor
        self.preco = preco
        self.estoque = estoque
    
    def pedido(self, quantidade):
        if quantidade > self.estoque:
            (print(f"A Quantidade de {quantidade} é insuficiente em nosso estoque :("))
        else:
            self.estoque -= quantidade
            total = quantidade * self.preco
            (print(f"Pedido Realizado! Valor: R${total} - Estoque Atual: {self.estoque} unidades"))

    def producao(self, quantidade):
        self.estoque += quantidade 
        (print(f"Estoque Abastecido com: {quantidade} unidades - Estoque Atual: {self.estoque} unidades"))
    
    def detalhes(self):
        print(f"Doce:{self.nome} - Sabor:{self.sabor} - Preço:{self.preco} - Estoque:{self.estoque}")




