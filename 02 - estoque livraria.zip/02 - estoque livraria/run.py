import livraria

livro = livraria.Livraria("1984", "George Orwell", 45.90, 10)
livro.detalhes()
livro.vender(3)
livro.reabastecer(5)
livro.vender(22)