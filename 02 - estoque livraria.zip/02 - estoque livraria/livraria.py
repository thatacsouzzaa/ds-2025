class Livraria:
    def __init__(self, titulo, autor, valor, estoque):
        self.titulo = titulo
        self.autor = autor
        self.valor = valor
        self.estoque = estoque

    def vender (self, quantidade):
        if quantidade > self.estoque:
            print("Estoque insuficiente para venda!")
        else:
            self.estoque -= quantidade
            total = quantidade * self.valor
            print(f"Venda Realizada! Total:{total:2f}")

    def reabastecer(self, quantidade):
        self.estoque += quantidade
        print (f"Estoque atualizado com sucesso! {self.estoque} unidades.")

    def detalhes(self):
        print(f"Livro cadastro: {self.titulo} - Autor: {self.autor} - Preço: R$ {self.valor} - Estoque: {self.estoque}")