import clientes
import veiculos

cliente = clientes.Clientes("João Silva", "joao.silva@email.com", "(11) 99999-9999", "Rua das Palmeiras, 123")
cliente.consulta ()

veiculo = veiculos.Veiculos("HB20", "Hyundai", "2023", 120.00, 3)
veiculo.aluguel (2)
veiculo.devolucao ()
veiculo.aluguel (3)
