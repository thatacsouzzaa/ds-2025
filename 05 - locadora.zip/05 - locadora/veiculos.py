class Veiculos:
    def __init__(self, modelo, marca, ano, valordiario, unidadesdisponiveis ):
        self.modelo = modelo 
        self.marca = marca
        self.ano = ano
        self.valordiario = valordiario
        self.unidadesdisponiveis = unidadesdisponiveis

    def aluguel(self, quantidade):
        if quantidade > self.unidadesdisponiveis:
            print(f"Não temos disponibilidade para essa quantidade - Unidades Disponiveis: {self.unidadesdisponiveis}")
        else: 
            quantidade -= self.unidadesdisponiveis
            valor = self.valordiario * quantidade 
            print(f"Aluguel realizado! Valor:{valor}")

    def devolucao (self, quantidade):
        self.estoque += quantidade
        print(f"Estoque atualizado!")

    def detalhes (self):
        print(f"Modelo: {self.modelo} - Marca: {self.marca} - Ano:{self.ano} - Valor da Diário:{self.valordiario} - Disponibilidade: {self.unidadesdisponiveis}")
        