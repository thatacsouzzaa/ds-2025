class Clientes:
    def __init__(self, nome, email, telefone, endereco):
        self.nome = nome
        self.email = email
        self.telefone = telefone
        self.endereco = endereco

    def consulta(self):
        (print(f"Nome: {self.nome} - Email: {self.email} - Telefone: {self.telefone} - Endereço: {self.endereco}"))

