from clientes import Cliente

c1 = Cliente("fulano", "fulano@gmail.com", "2222-2222")
c1.inserir_dados()